"""Render tracker annotations above the interactive drum pads."""

from __future__ import annotations

import cv2
import numpy as np


class FingerRenderer:
    """Composite the existing tracker landmark drawing without changing tracking."""

    def draw(self, frame: np.ndarray, camera_frame: np.ndarray, annotated_frame: np.ndarray) -> None:
        """Copy only HandTracker's changed annotation pixels over the drum overlay."""
        difference = cv2.absdiff(camera_frame, annotated_frame)
        annotation_mask = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY) > 1
        frame[annotation_mask] = annotated_frame[annotation_mask]
